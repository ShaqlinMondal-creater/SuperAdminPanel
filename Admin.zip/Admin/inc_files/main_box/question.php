<div class="grid lg:grid-cols-2 gap-5 lg:gap-7.5">
    <div class="card">
         <div class="card-body px-10 py-7.5 lg:pr-12.5">
              <div class="flex flex-wrap md:flex-nowrap items-center gap-6 md:gap-10">
                   <div class="flex flex-col items-start gap-3">
                        <h2 class="text-1.5xl font-medium text-gray-900">
                             Questions ?
                        </h2>
                        <p class="text-sm text-gray-800 leading-5.5 mb-2.5">
                             Visit our Help Center for detailed assistance on
                             billing, payments, and subscriptions.
                        </p>
                   </div>
                   <img alt="image" class="dark:hidden max-h-[150px]"
                        src="assets/media/illustrations/29.svg" />
                   <img alt="image" class="light:hidden max-h-[150px]"
                        src="assets/media/illustrations/29-dark.svg" />
              </div>
         </div>
         <div class="card-footer justify-center">
              <a class="btn btn-link" href="">
                   Go to Help Center
              </a>
         </div>
    </div>
    <div class="card">
         <div class="card-body px-10 py-7.5 lg:pr-12.5">
              <div class="flex flex-wrap md:flex-nowrap items-center gap-6 md:gap-10">
                   <div class="flex flex-col items-start gap-3">
                        <h2 class="text-1.5xl font-medium text-gray-900">
                             Contact Support
                        </h2>
                        <p class="text-sm text-gray-800 leading-5.5 mb-2.5">
                             Need assistance? Contact our support team for
                             prompt, personalized help your queries & concerns.
                        </p>
                   </div>
                   <img alt="image" class="dark:hidden max-h-[150px]"
                        src="assets/media/illustrations/31.svg" />
                   <img alt="image" class="light:hidden max-h-[150px]"
                        src="assets/media/illustrations/31-dark.svg" />
              </div>
         </div>
         <div class="card-footer justify-center">
              <a class="btn btn-link" href="https://devs.keenthemes.com/unresolved">
                   Contact Support
              </a>
         </div>
    </div>
</div>