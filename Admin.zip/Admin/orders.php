<!DOCTYPE html>
<html class="h-full" data-theme="true" data-theme-mode="light" dir="ltr" lang="en">

<head>
     <!-- <base href="../../../../"> -->
     <title>
          Metronic - Tailwind CSS Store Clients
     </title>
     <meta charset="utf-8" />
     <meta content="follow, index" name="robots" />
     <link href="https://127.0.0.1:8001/metronic-tailwind-html/demo6/network/user-table/store-clients"
          rel="canonical" />
     <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport" />
     <meta content="Store clients table, using Tailwind CSS" name="description" />
     <meta content="@keenthemes" name="twitter:site" />
     <meta content="@keenthemes" name="twitter:creator" />
     <meta content="summary_large_image" name="twitter:card" />
     <meta content="Metronic - Tailwind CSS Store Clients" name="twitter:title" />
     <meta content="Store clients table, using Tailwind CSS" name="twitter:description" />
     <meta content="assets/media/app/og-image.png" name="twitter:image" />
     <meta content="https://127.0.0.1:8001/metronic-tailwind-html/demo6/network/user-table/store-clients"
          property="og:url" />
     <meta content="en_US" property="og:locale" />
     <meta content="website" property="og:type" />
     <meta content="@keenthemes" property="og:site_name" />
     <meta content="Metronic - Tailwind CSS Store Clients" property="og:title" />
     <meta content="Store clients table, using Tailwind CSS" property="og:description" />
     <meta content="assets/media/app/og-image.png" property="og:image" />
     <link href="assets/media/app/apple-touch-icon.png" rel="apple-touch-icon" sizes="180x180" />
     <link href="assets/media/app/favicon-32x32.png" rel="icon" sizes="32x32" type="image/png" />
     <link href="assets/media/app/favicon-16x16.png" rel="icon" sizes="16x16" type="image/png" />
     <link href="assets/media/app/favicon.ico" rel="shortcut icon" />
     <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
     <link href="assets/vendors/apexcharts/apexcharts.css" rel="stylesheet" />
     <link href="assets/vendors/keenicons/styles.bundle.css" rel="stylesheet" />
     <link href="assets/css/styles.css" rel="stylesheet" />
</head>

<body
     class="antialiased flex h-full text-base text-gray-700 [--tw-page-bg:#F6F6F9] [--tw-page-bg-dark:var(--tw-coal-200)] [--tw-content-bg:var(--tw-light)] [--tw-content-bg-dark:var(--tw-coal-500)] [--tw-content-scrollbar-color:#e8e8e8] [--tw-header-height:60px] [--tw-sidebar-width:270px] bg-[--tw-page-bg] dark:bg-[--tw-page-bg-dark] lg:overflow-hidden">
     <!-- Theme Mode -->
     <script>
          const defaultThemeMode = 'light'; // light|dark|system
          let themeMode;

          if (document.documentElement) {
               if (localStorage.getItem('theme')) {
                    themeMode = localStorage.getItem('theme');
               } else if (document.documentElement.hasAttribute('data-theme-mode')) {
                    themeMode = document.documentElement.getAttribute('data-theme-mode');
               } else {
                    themeMode = defaultThemeMode;
               }

               if (themeMode === 'system') {
                    themeMode = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
               }

               document.documentElement.classList.add(themeMode);
          }
     </script>
     <!-- End of Theme Mode -->
     <!-- Page -->
     <!-- Base -->
     <div class="flex grow">
          <!-- Header -->
          <?php include("inc_files/header.php"); ?>
          <!-- End of Header -->

          <!-- Sidebar -->
          <?php include("inc_files/sidebar.php"); ?>
          <!-- End of Sidebar -->

          <!-- Wrapper -->
          <div class="flex flex-col lg:flex-row grow pt-[--tw-header-height] lg:pt-0">
               <!-- Main -->
               <div
                    class="flex flex-col grow items-stretch rounded-xl bg-[--tw-content-bg] dark:bg-[--tw-content-bg-dark] border border-gray-300 dark:border-gray-200 lg:ms-[--tw-sidebar-width] mt-0 lg:mt-[15px] m-[15px]">
                    <div class="flex flex-col grow lg:scrollable-y-auto lg:[scrollbar-width:auto] lg:light:[--tw-scrollbar-thumb-color:var(--tw-content-scrollbar-color)] pt-5"
                         id="scrollable_content">

                         <!-- main box -->
                         <main class="grow" role="content">

                              <!-- Toolbar -->
                              <div class="pb-5">
                                   <!-- Container -->
                                   <div class="container-fixed flex items-center justify-between flex-wrap gap-3">
                                        <div class="flex items-center flex-wrap gap-1 lg:gap-5">
                                             <h1 class="font-medium text-lg text-gray-900">
                                                  Orders Table
                                             </h1>
                                             <div class="flex items-center gap-1 text-sm font-normal">
                                                  <a class="text-gray-700 hover:text-primary" href="html/demo6.html">
                                                       Home
                                                  </a>
                                                  <span class="text-gray-400 text-sm">
                                                       /
                                                  </span>
                                                  <span class="text-gray-900">
                                                       Orders
                                                  </span>
                                             </div>
                                        </div>
                                        <div class="flex items-center flex-wrap gap-1.5 lg:gap-3.5">
                                             <a class="btn btn-sm btn-light" href="html/demo6/account/home/get-started.html">
                                                  <i class="ki-filled ki-exit-down !text-base">
                                                  </i>
                                                  Export
                                             </a>
                                             <div class="menu menu-default" data-menu="true">
                                                  <div class="menu-item" data-menu-item-offset="0, 0"
                                                       data-menu-item-placement="bottom-end" data-menu-item-toggle="dropdown"
                                                       data-menu-item-trigger="hover">
                                                       <button class="menu-toggle btn btn-light btn-sm flex-nowrap">
                                                            <span class="flex items-center me-1">
                                                                 <i class="ki-filled ki-calendar !text-md">
                                                                 </i>
                                                            </span>
                                                            <span class="hidden md:inline text-nowrap">
                                                                 September, 2024
                                                            </span>
                                                            <span class="inline md:hidden text-nowrap">
                                                                 Sep, 2024
                                                            </span>
                                                            <span class="flex items-center lg:ms-4">
                                                                 <i class="ki-filled ki-down !text-xs">
                                                                 </i>
                                                            </span>
                                                       </button>
                                                       <div class="menu-dropdown w-48 py-2 scrollable-y max-h-[250px]">
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           January, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           February, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item active">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           March, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           April, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           May, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           June, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           July, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           August, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           September, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           October, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           November, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                            <div class="menu-item">
                                                                 <a class="menu-link" href="#">
                                                                      <span class="menu-title">
                                                                           December, 2024
                                                                      </span>
                                                                 </a>
                                                            </div>
                                                       </div>
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                                   <!-- End of Container -->
                              </div>
                              <!-- End of Toolbar -->

                              <!-- Container -->
                              <div class="container-fixed">
                                   <div class="grid gap-5 lg:gap-7.5">
                                        <div class="card card-grid min-w-full">
                                             <div class="card-header flex-wrap gap-2">
                                                  <h3 class="card-title font-medium text-sm">
                                                       Showing 10 of 49,053 users
                                                  </h3>
                                                  <div class="flex flex-wrap gap-2 lg:gap-5">
                                                       <div class="flex">
                                                            <label class="input input-sm">
                                                                 <i class="ki-filled ki-magnifier">
                                                                 </i>
                                                                 <input placeholder="Search users" type="text"
                                                                      value="" />
                                                            </label>
                                                       </div>
                                                       <div class="flex flex-wrap gap-2.5">
                                                            <select class="select select-sm w-28">
                                                                 <option value="1">
                                                                      Active
                                                                 </option>
                                                                 <option value="2">
                                                                      Disabled
                                                                 </option>
                                                                 <option value="2">
                                                                      Pending
                                                                 </option>
                                                            </select>
                                                            <select class="select select-sm w-28">
                                                                 <option value="1">
                                                                      Latest
                                                                 </option>
                                                                 <option value="2">
                                                                      Older
                                                                 </option>
                                                                 <option value="3">
                                                                      Oldest
                                                                 </option>
                                                            </select>
                                                            <button class="btn btn-sm btn-outline btn-primary">
                                                                 <i class="ki-filled ki-setting-4">
                                                                 </i>
                                                                 Filters
                                                            </button>
                                                       </div>
                                                  </div>
                                             </div>
                                             <div class="card-body">
                                                  <div data-datatable="true" data-datatable-page-size="10">
                                                       <div class="scrollable-x-auto">
                                                            <table class="table table-auto table-border"
                                                                 data-datatable-table="true">
                                                                 <thead>
                                                                      <tr>
                                                                           <th class="w-[60px] text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-check="true"
                                                                                     type="checkbox" />
                                                                           </th>
                                                                           <th class="min-w-[300px]">
                                                                                <span class="sort asc">
                                                                                     <span class="sort-label">
                                                                                          User Name / mobile no
                                                                                     </span>
                                                                                     <span class="sort-icon">
                                                                                     </span>
                                                                                </span>
                                                                           </th>
                                                                           <th class="min-w-[150px]">
                                                                                <span class="sort">
                                                                                     <span class="sort-label">
                                                                                          Order ID
                                                                                     </span>
                                                                                     <span class="sort-icon">
                                                                                     </span>
                                                                                </span>
                                                                           </th>
                                                                           <th class="min-w-[150px]">
                                                                                <span class="sort">
                                                                                     <span class="sort-label">
                                                                                          Orders Value / Date
                                                                                     </span>
                                                                                     <span class="sort-icon">
                                                                                     </span>
                                                                                </span>
                                                                           </th>
                                                                           <th class="min-w-[150px]">
                                                                                <span class="sort">
                                                                                     <span class="sort-label">
                                                                                          Type
                                                                                     </span>
                                                                                     <span class="sort-icon">
                                                                                     </span>
                                                                                </span>
                                                                           </th>
                                                                           <th class="min-w-[150px]">
                                                                                <span class="sort">
                                                                                     <span class="sort-label">
                                                                                          Status Activity
                                                                                     </span>
                                                                                     <span class="sort-icon">
                                                                                     </span>
                                                                                </span>
                                                                           </th>
                                                                           <th class="w-[100px] text-center">
                                                                                <span class="sort">
                                                                                     <span class="sort-label">
                                                                                          PDF Invoices
                                                                                     </span>
                                                                                     <span class="sort-icon">
                                                                                     </span>
                                                                                </span>
                                                                           </th>
                                                                           <th class="w-[60px]">
                                                                           </th>
                                                                      </tr>
                                                                 </thead>
                                                                 <tbody>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="1" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-3.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Tyler Hero
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               tyler.hero@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-23456832
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $27,456.09
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/estonia.svg" />
                                                                                     Estonia
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="2" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-1.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Esther Howard
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               esther.howard@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-52967418
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $45,800.90
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/malaysia.svg" />
                                                                                     Malaysia
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Week ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="3" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-11.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Jacob Jones
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               jacob.jones@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-43765928
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $63,250.30
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/ukraine.svg" />
                                                                                     Ukraine
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Today, 9:53 am
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="4" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-2.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Cody Fisher
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               cody.fisher@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-29846571
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $80,100.45
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/canada.svg" />
                                                                                     Canada
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="5" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-5.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Leslie Alexander
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               leslie.alexander@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-71639482
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $56,500.60
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/india.svg" />
                                                                                     India
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Month ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="6" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-4.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Robert Fox
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               robert.fox@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-65438729
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $70,342.25
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/united-states.svg" />
                                                                                     USA
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Today, 15:02
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="7" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-20.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Guy Hawkins
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               guy.hawkins@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-58372914
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $40,210.15
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/turkey.svg" />
                                                                                     Turkey
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="8" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-23.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Theresa Webb
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               theresa.webb@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-47298356
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $52,315.70
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/brazil.svg" />
                                                                                     Brasil
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="9" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-22.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Marvin McKinney
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               marvin.mckenney@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-83926145
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $68,450.55
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/latvia.svg" />
                                                                                     Latvia
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Week ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="10" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-18.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Ronald Richards
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               ronald.richards@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-72649538
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $73,270.80
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/uruguay.svg" />
                                                                                     Uruguay
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="11" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-6.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               William Wilson
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               william.wilson@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-98473654
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $28,456.22
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/germany.svg" />
                                                                                     Germany
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Yesterday
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="12" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-7.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Sophia Anderson
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               sophia.anderson@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-23784956
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $46,800.90
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/france.svg" />
                                                                                     France
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                2 days ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="13" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-8.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Mason Taylor
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               mason.taylor@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-48723659
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $66,350.30
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/italy.svg" />
                                                                                     Italy
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Today, 8:45 am
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="14" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-9.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Isabella Lee
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               isabella.lee@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-29374685
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $90,150.45
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/japan.svg" />
                                                                                     Japan
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="15" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-10.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               James Martinez
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               james.martinez@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-73649281
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $54,600.60
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/mexico.svg" />
                                                                                     Mexico
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Week ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="16" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-12.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Emily Thomas
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               emily.thomas@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-47682953
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $74,342.25
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/south-korea.svg" />
                                                                                     South Korea
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Today, 14:10
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="17" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-13.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Benjamin Harris
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               benjamin.harris@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-58394721
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $33,210.15
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/russia.svg" />
                                                                                     Russia
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="18" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-14.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Charlotte Young
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               charlotte.young@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-69583742
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $52,315.70
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/spain.svg" />
                                                                                     Spain
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                3 days ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="19" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-15.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Henry Clark
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               henry.clark@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-98237645
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $68,450.55
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/portugal.svg" />
                                                                                     Portugal
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Week ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="20" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-16.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Amelia Lewis
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               amelia.lewis@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-46537289
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $73,270.80
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/netherlands.svg" />
                                                                                     Netherlands
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="21" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-17.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Lucas Walker
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               lucas.walker@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-29374650
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $57,456.09
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/belgium.svg" />
                                                                                     Belgium
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Yesterday
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="22" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-19.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Grace Allen
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               grace.allen@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-47682953
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $85,800.90
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/sweden.svg" />
                                                                                     Sweden
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                2 days ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="23" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-21.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Jack Harris
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               jack.harris@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-83926145
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $63,250.30
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/norway.svg" />
                                                                                     Norway
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Today, 11:53 am
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="24" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-24.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Aiden King
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               aiden.king@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-29846571
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $90,100.45
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/denmark.svg" />
                                                                                     Denmark
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="25" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-25.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Avery Green
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               avery.green@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-71639482
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $56,500.60
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/austria.svg" />
                                                                                     Austria
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Month ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="26" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-26.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Ella White
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               ella.white@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-65438729
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $70,342.25
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/poland.svg" />
                                                                                     Poland
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Today, 15:02
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="27" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-27.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Henry King
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               henry.king@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-58372914
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $40,210.15
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/switzerland.svg" />
                                                                                     Switzerland
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="28" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-28.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Olivia Green
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               olivia.green@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-47298356
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $52,315.70
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/finland.svg" />
                                                                                     Finland
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="29" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-29.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Mason Lewis
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               mason.lewis@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-83926145
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $68,450.55
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/ireland.svg" />
                                                                                     Ireland
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Week ago
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="30" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-30.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Sophia Lee
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               sophia.lee@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-72649538
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $73,270.80
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/portugal.svg" />
                                                                                     Portugal
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                      <tr>
                                                                           <td class="text-center">
                                                                                <input class="checkbox checkbox-sm"
                                                                                     data-datatable-row-check="true"
                                                                                     type="checkbox" value="31" />
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-2.5">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-7 shrink-0"
                                                                                          src="assets/media/avatars/300-31.png" />
                                                                                     <div class="flex flex-col">
                                                                                          <a class="text-sm font-medium text-gray-900 hover:text-primary-active mb-px"
                                                                                               href="#">
                                                                                               Matthew Martinez
                                                                                          </a>
                                                                                          <a class="text-2sm text-gray-700 font-normal hover:text-primary-active"
                                                                                               href="#">
                                                                                               matthew.martinez@gmail.com
                                                                                          </a>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                MS-23456832
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                $27,456.09
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex items-center gap-1.5 class="
                                                                                     font-normal""="" text-gray-800="">
                                                                                     <img alt=""
                                                                                          class="rounded-full size-4 shrink-0"
                                                                                          src="assets/media/flags/estonia.svg" />
                                                                                     Estonia
                                                                                </div>
                                                                           </td>
                                                                           <td class="text-gray-800 font-normal">
                                                                                Current session
                                                                           </td>
                                                                           <td>
                                                                                <div class="flex justify-center">
                                                                                     <a class="btn btn-link" href="">
                                                                                          View
                                                                                     </a>
                                                                                </div>
                                                                           </td>
                                                                           <td>
                                                                                <div class="menu" data-menu="true">
                                                                                     <div class="menu-item"
                                                                                          data-menu-item-offset="0, 10px"
                                                                                          data-menu-item-placement="bottom-end"
                                                                                          data-menu-item-placement-rtl="bottom-start"
                                                                                          data-menu-item-toggle="dropdown"
                                                                                          data-menu-item-trigger="click|lg:click">
                                                                                          <button
                                                                                               class="menu-toggle btn btn-sm btn-icon btn-light btn-clear">
                                                                                               <i
                                                                                                    class="ki-filled ki-dots-vertical">
                                                                                               </i>
                                                                                          </button>
                                                                                          <div class="menu-dropdown menu-default w-full max-w-[175px]"
                                                                                               data-menu-dismiss="true">
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-search-list">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              View
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-file-up">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Export
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-pencil">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Edit
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-copy">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Make a
                                                                                                              copy
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                               <div
                                                                                                    class="menu-separator">
                                                                                               </div>
                                                                                               <div class="menu-item">
                                                                                                    <a class="menu-link"
                                                                                                         href="#">
                                                                                                         <span
                                                                                                              class="menu-icon">
                                                                                                              <i
                                                                                                                   class="ki-filled ki-trash">
                                                                                                              </i>
                                                                                                         </span>
                                                                                                         <span
                                                                                                              class="menu-title">
                                                                                                              Remove
                                                                                                         </span>
                                                                                                    </a>
                                                                                               </div>
                                                                                          </div>
                                                                                     </div>
                                                                                </div>
                                                                           </td>
                                                                      </tr>
                                                                 </tbody>
                                                            </table>
                                                       </div>
                                                       <div
                                                            class="card-footer justify-center md:justify-between flex-col md:flex-row gap-5 text-gray-600 text-2sm font-medium">
                                                            <div class="flex items-center gap-2 order-2 md:order-1">
                                                                 Show
                                                                 <select class="select select-sm w-16"
                                                                      data-datatable-size="true" name="perpage">
                                                                 </select>
                                                                 per page
                                                            </div>
                                                            <div class="flex items-center gap-4 order-1 md:order-2">
                                                                 <span data-datatable-info="true">
                                                                 </span>
                                                                 <div class="pagination"
                                                                      data-datatable-pagination="true">
                                                                 </div>
                                                            </div>
                                                       </div>
                                                  </div>
                                             </div>
                                        </div>
                                        <?php include("inc_files/main_box/faq.php"); ?>
                                        <?php include("inc_files/main_box/question.php"); ?>
                                   </div>
                              </div>
                              <!-- End of Container -->

                         </main>
                         <!--end main box -->

                         <!-- Footer -->
                         <?php include("inc_files/footer.php"); ?>
                         <!-- End of Footer -->
                    </div>
               </div>
               <!-- End of Main -->
          </div>
          <!-- End of Wrapper -->
     </div>
     <!-- End of Base -->
     <?php include("inc_files/modals.php"); ?>
     <!-- End of Page -->
     <!-- Scripts -->
     <script src="assets/js/core.bundle.js">
     </script>
     <script src="assets/vendors/apexcharts/apexcharts.min.js">
     </script>
     <!-- End of Scripts -->
</body>

</html>